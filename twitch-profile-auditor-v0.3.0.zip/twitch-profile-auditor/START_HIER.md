# Twitch-Profilcheck starten

## Einmal einrichten (Windows / PowerShell)

ZIP entpacken. PowerShell im Ordner mit `twitch_audit.py` öffnen:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m playwright install chromium
Copy-Item .env.example .env
```

`.env` im Texteditor öffnen und einen eigenen `OPENAI_API_KEY` eintragen. Keine Schlüssel in Chats teilen. Der im Beispiel konfigurierte Modellname ist austauschbar; ein Modell mit Bildinput und Structured Outputs verwenden. Für genaue Muted-Zeitbereiche und ergänzende Twitch-Metadaten optional `TWITCH_CLIENT_ID` und `TWITCH_CLIENT_SECRET` ergänzen.

## Automatisch erfassen und mit KI auswerten

```powershell
.\.venv\Scripts\python.exe twitch_audit.py run earlysalty --consent --ai-consent --style-reference-images --max-vods 5 --playback
```

Der Browser öffnet die freigegebenen Kanalansichten, scrollt und erfasst Bilder. Die KI erhält diese Bilder und Text-/Linkbelege, bewertet nach deinen Stilvorgaben und liefert Feedback. Danach entsteht `report.html` im angezeigten Auditordner.

`--consent` bestätigt den erlaubten Kanalcheck. `--ai-consent` bestätigt die Übermittlung der ausgewählten Kanalbelege an die OpenAI-API. `--style-reference-images` erlaubt zusätzlich den Upload der elf mitgelieferten Beispielausschnitte. Ohne diesen letzten Schalter werden **die Zielkanal-Screenshots trotzdem mit KI analysiert**, die Stilpräferenzen jedoch nur als Text mitgegeben.

Die Beispielausschnitte kannst du vorher in `style_references/index.html` ansehen. Für einen anderen freigegebenen Kanal `earlysalty` durch den Kanalnamen ersetzen. Keine Anmeldung nötig; das Skript nutzt die Gastperspektive. API-Nutzung kann Kosten verursachen.

## Vor dem Senden nur lokal prüfen

```powershell
.\.venv\Scripts\python.exe twitch_audit.py collect earlysalty --consent
```

Danach `collection.html` ansehen. Erst mit `analyze AUDITORDNER --ai-consent` werden die gespeicherten Zielbelege an die KI gesendet. Dieser zweistufige Ablauf ist optional, nicht für jeden Lauf erforderlich.

## Teststand

84 lokale Tests bestanden; Browser-Screenshots werden tatsächlich in einen simulierten KI-Request eingebaut. Kein echter OpenAI-Modelllauf in dieser Umgebung. Die Ausführungsumgebung blockierte hier den Twitch-Browseraufruf, daher liegt kein fertiges Urteil über `earlysalty` vor. Vollständige Anleitung und Grenzen: `README.md`.
