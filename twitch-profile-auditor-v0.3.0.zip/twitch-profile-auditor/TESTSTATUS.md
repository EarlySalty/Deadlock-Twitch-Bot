# Teststatus – Version 0.3.0 · 5. Oktober 2026

## Automatisierte Tests

**84 Tests bestanden.** Aufruf in der Entwicklungsumgebung:

```bash
AUDIT_TEST_BROWSER=/usr/bin/chromium python -m pytest -q --disable-warnings
```

Unter Windows nach `python -m playwright install chromium` ohne diese Linux-Umgebungsvariable `python -m pytest -q` verwenden. In der Entwicklungsumgebung wird das vorhandene System-Chromium verwendet, da die von Playwright erwartete Download-Browserversion hier nicht installiert ist.

Die 64 bestehenden Tests bleiben erhalten: URL-/Dateipfadgrenzen, Zustimmungsflags, Gewichtung, Nicht-prüfbar-Logik, Muted-Zeitmarken, Abo-Gates, generische Abo-Buttons, Login-/Alters-/Fehlerzustände, API-/UI-Widersprüche, Belegvalidierung, HTML-Escaping und Report-Erzeugung.

20 zusätzliche Testfälle prüfen die elf Referenzen, ihre Bilddaten/Prüfsummen, Pfadgrenzen, doppelte IDs, explizite Referenzbild-Freigabe, Bildbudget, Trennung von Stilreferenzen und Zielkanal-Belegen, bevorzugte About-Bilder sowie Zeitpläne in About und widersprechende API-Belege.

Ein neuer Integrationstest führt den tatsächlichen Ablauf **gerendertes lokales Browser-HTML → echter Screenshot → Bilddaten im API-Request → simulierte Modellantwort → HTML/JSON-Report** aus. Dabei enthält der Request die tatsächlichen Zielbilddaten plus elf Referenzbilder. Die Tests verwenden keine echten API-Schlüssel.

Die Browser-Tests rendern lokales Test-HTML in Chromium. Seitennavigation wird für die Integrationstests durch `set_content` ersetzt. Helix und OpenAI antworten dort aus HTTP-Mocks. Dies bestätigt nicht, dass Twitchs aktuelle Selektoren überall passen oder eine echte Modellbewertung deinem Geschmack entspricht. **Kein echter OpenAI-Modelllauf wurde durchgeführt.**

## Erneuter Live-Aufruf am freigegebenen Kanal earlysalty

Die aktuelle Version hat den Browser am 5. Oktober 2026 erneut auf `https://www.twitch.tv/earlysalty` navigieren lassen. Der Aufruf wurde von der Ausführungsumgebung blockiert:

```text
Page.goto: net::ERR_BLOCKED_BY_ADMINISTRATOR
```

Daraufhin wurden keine weiteren Kanalansichten angefordert. Der Fehler steht im Erfassungsdatensatz; er wird nicht als leerer Kanal, fehlende Clips oder schlechte Gestaltung bewertet. Für diesen Versuch wurden keine Twitch-API-Schlüssel und kein OpenAI-Schlüssel verwendet.

**Es liegt kein vollständiger Live-Bericht über earlysalty vor.** Der praktische End-to-End-Test mit Twitch und einem echten bildfähigen Modell bleibt auf deinem berechtigten lokalen Rechner nötig.

## Weitere Prüfungen

Python-Syntaxprüfung und JavaScript-Ausdrucksprüfung, Sichtprüfung der elf Referenzausschnitte sowie lokale Layoutprüfung des HTML-Reports. Versionsliste: `tested-environment.txt`; letzter Testlauf: `test-results.txt`.
