# Twitch-Profil-Auditor

**Lokaler Prototyp · Version 0.3.0 · Deutschsprachiger Feedback-Report**

Ein echter Chromium-Browser besucht ein freigegebenes Twitch-Profil. Das Programm sammelt sichtbare Inhalte und Screenshots, ergänzt auf Wunsch offizielle Twitch-API-Daten und lässt eine bildfähige KI die Belege bewerten. Die KI steuert dabei keine unkontrollierten Aktionen: Navigation, Erfassung und technische Prüfregeln bleiben im Python-Code.

**Wichtig zum Testkanal `earlysalty`:** Der Browser-Aufruf wurde in der Entwicklungsumgebung mit `net::ERR_BLOCKED_BY_ADMINISTRATOR` blockiert. Das ist kein Befund über den Kanal. Hier liegt weder ein vollständiger Live-Profilcheck noch eine echte KI-Auswertung dieses Kanals vor. Die lokalen Funktionstests sind in `TESTSTATUS.md` beschrieben. Twitch-spezifische Selektoren können beim ersten tatsächlichen Lauf angepasst werden müssen.

## Ein Befehl: Browser → Screenshots → KI → Report

Das ist keine reine Panel-Zählung und kein Textbericht ohne Bildinput. `run` führt beide Schritte automatisch nacheinander aus: Playwright öffnet die Seiten und erfasst Screenshots; die offizielle OpenAI-Responses-API erhält die tatsächlichen Bilddaten plus strukturierte Seitenbelege. Das Modell liefert bewertete Einzelbefunde, aus denen der lokale Code den Bericht erzeugt. Der Report wird nicht automatisch veröffentlicht.

**Neu in 0.3.0:** Deine elf Bildbeispiele und Kommentare sind als Gestaltungsmaßstab hinterlegt. Die textlichen Stilvorlieben werden bei jeder Analyse mitgegeben. Die elf zugeschnittenen Referenzbilder werden nur mit `--style-reference-images` zusätzlich übertragen. Das ist eine Kalibrierung durch Vorgaben und Beispiele pro Anfrage, **kein Modelltraining** und keine Garantie für identische Geschmacksurteile.

Nach Installation und Schlüsselkonfiguration läuft der vollständige Check einschließlich visueller Stilreferenzen unter Windows so:

```powershell
.\.venv\Scripts\python.exe twitch_audit.py run earlysalty --consent --ai-consent --style-reference-images --max-vods 5 --playback
```

Ohne `--style-reference-images` erhält die KI weiterhin die **Screenshots des geprüften Kanals** und deine **textlichen Stilvorlieben**, aber keine Bilder der anderen Beispielkanäle. Details und Voraussetzungen stehen unten.

## Was der Check erfasst

| Bereich | Erfassung und Bewertung |
| --- | --- |
| Home | Erster Eindruck, Offline-Einstieg, sichtbare Inhalte, Trailer und Orientierung, soweit angezeigt |
| Profil / About | Profilbild, sichtbares Banner, Kanalbeschreibung, verlinkte Socials, Panels, Gestaltung und Lesbarkeit |
| Videos | Video-Übersicht, vergangene Übertragungen und Highlights; Vorhandensein ist nicht gleich Abspielbarkeit |
| Clips | Clips mit Auswahl über alle Zeiträume; separate API-Abfrage für hervorgehobene Clips |
| Abo-Schranken | Explizite Hinweise im VOD-Player; ein gewöhnlicher Abonnieren-Button wird nicht als Sperre gewertet |
| Muted-Stellen | `muted_segments` mit Anfang/Ende pro VOD; zusätzlich ausdrückliche Player-Hinweise, soweit erkennbar |
| Schedule | Öffentliche zukünftige Termine und sichtbare Zeitplanung; geringe Gewichtung |
| Weitere Tabs | Bis zu vier weitere sichtbare Navigationsziele desselben Kanals, innerhalb der Sicherheitsgrenzen |

Standardmäßig werden bis zu **fünf VODs**, sechs zusätzliche Scrollschritte pro Profilansicht und 24 Zielkanal-Bilder für die KI verwendet. Bei der Bildauswahl erhält jede erfasste Ansicht zunächst ein Bild; danach werden weitere About-Screenshots und anschließend Home-Screenshots bevorzugt. Mit `--style-reference-images` kommen bis zu elf Referenzbilder hinzu; das gemeinsame Datenbudget wird weiterhin begrenzt. Es ist eine begrenzte Momentaufnahme, kein vollständiger Crawl aller Videos oder ein Test jedes Geräts.

## Installation

Benötigt werden Python 3.11 oder neuer, eine Desktop-Umgebung für das sichtbare Browserfenster und die Python-Pakete aus `requirements.txt`.

### Windows / PowerShell

ZIP entpacken und PowerShell im entpackten Ordner öffnen:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m playwright install chromium
Copy-Item .env.example .env
```

Die folgenden Windows-Befehle verwenden direkt die Python-Datei in der virtuellen Umgebung. Eine Änderung der PowerShell-Ausführungsrichtlinie ist nicht nötig.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m playwright install chromium
cp .env.example .env
```

Unter Linux können zusätzliche Systembibliotheken nötig sein. Playwright beschreibt diese in seiner Installationsdokumentation [7]. Auf einem Rechner ohne grafische Oberfläche kann `--headless` verwendet werden; standardmäßig öffnet sich ein sichtbares Fenster.

## Schlüssel konfigurieren

In `.env` stehen nur lokale Zugangsdaten:

```dotenv
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1

TWITCH_CLIENT_ID=
TWITCH_CLIENT_SECRET=
TWITCH_ACCESS_TOKEN=
```

Für die reine Browser-Erfassung ist kein KI-Schlüssel erforderlich. Für die KI-Bewertung wird ein eigener OpenAI-API-Schlüssel benötigt. `OPENAI_MODEL` ist austauschbar; das gewählte Modell muss Bildinput und strukturierte JSON-Ausgaben unterstützen. Die Implementierung nutzt die offizielle Responses-API direkt über HTTPS, ohne ein zusätzliches OpenAI-SDK [5, 6].

**Für exakte Muted-Zeitmarken und zuverlässige Clip-Abfragen die Twitch-Zugangsdaten ergänzen.** Dazu eine eigene Twitch-Entwickleranwendung registrieren und deren Client-ID und Client-Secret eintragen [4]. Das Programm beschafft damit ein App-Access-Token. Alternativ kann ein bereits gültiges, zur Client-ID passendes Token in `TWITCH_ACCESS_TOKEN` stehen. Ist ein Token eingetragen, wird es bevorzugt. Es werden keine Schreibberechtigungen für deinen Kanal benötigt; das Skript nutzt nur lesende Helix-Endpunkte für Profildaten, Videos, Clips und Zeitplan [1–3].

Echte Schlüssel niemals in Chatnachrichten, öffentliche Repositories oder Reports kopieren. `.env`, Browser-Ausgaben und virtuelle Umgebungen stehen in `.gitignore`.

## Empfohlener erster Lauf: nur Belege sammeln

```powershell
.\.venv\Scripts\python.exe twitch_audit.py collect earlysalty --consent --max-vods 5 --playback
```

Unter macOS/Linux mit aktivierter Umgebung:

```bash
python twitch_audit.py collect earlysalty --consent --max-vods 5 --playback
```

Der Browser startet frisch und ausgeloggt. Nicht mit dem Streamer-, Moderator- oder Abonnentenkonto anmelden: Diese Konten bilden die Perspektive eines neuen Besuchers nicht zuverlässig ab.

`--consent` bestätigt, dass es dein Kanal ist oder die Zustimmung des Streamers dokumentiert wurde. Mit `--consent-note "Vorgang 123"` lässt sich eine eigene Referenz speichern. Der Schalter ersetzt keine tatsächliche Zustimmungsdokumentation.

Nach dem Lauf `collection.html` im angezeigten Ausgabeordner öffnen. Screenshots, Textbelege, API-Status und eventuelle Blockaden sind dort sichtbar. **Ein Ladefehler darf nicht als leeres Profil bewertet werden.**

### Anschließend gespeicherte Belege mit KI auswerten

```powershell
.\.venv\Scripts\python.exe twitch_audit.py analyze "audits\DEIN_ERZEUGTER_AUDITORDNER" --ai-consent
```

`--ai-consent` ist die getrennte Bestätigung, dass ausgewählte Screenshots und öffentliche Profilbelege an die OpenAI-API übertragen werden dürfen. Die Seitenleiste und der Chat werden bei Screenshots soweit über die vorgesehenen Selektoren erkennbar maskiert. Vor der Übertragung trotzdem die Belege prüfen.

### Oder Erfassung und KI in einem Lauf

```powershell
.\.venv\Scripts\python.exe twitch_audit.py run earlysalty --consent --ai-consent --max-vods 5 --playback
```

Unter macOS/Linux:

```bash
python twitch_audit.py run earlysalty --consent --ai-consent --max-vods 5 --playback
```

## Dein Gestaltungsmaßstab

Die Datei `style_profile.json` enthält deine Stilvorlieben und die Zuordnung aller elf Beispiele. `style_references/index.html` zeigt die mitgelieferten Bildausschnitte und Kommentare lokal im Browser. Browserleisten, Chat und Taskleiste sind aus den Referenzen herausgeschnitten; es ist keine vollständige Anonymisierung. Texte, Grafiken oder Personen aus den öffentlichen Profilansichten können weiterhin sichtbar sein.

| Beispiel aus deinen Uploads | Hinterlegtes Nutzerurteil |
| --- | --- |
| 1 | Zu leer. |
| 2 | Clean, nicht zu viel, leichte Verzierungen und markantes Hasenmotiv gefallen. |
| 3 | Solider Inhaltseinstieg auf der Startseite. |
| 4 | Große Grafik mit für dich störender KI-Anmutung; Buttons und Größen als Einstieg okay. |
| 5 | Insgesamt okay. |
| 6 | Cute, clean und thematisch passend; kein Pflichtbudget für kleinere Kanäle. |
| 7 | Zum Kanal passend. |
| 8 | Schlicht und recht clean. |
| 9 | Trotz von dir vermutetem KI-Einsatz akzeptabel. |
| 10 | Besser als nichts, aber persönlich nicht dein bevorzugter Stil und zu viel. |
| 11 | Optisch trotz vermutetem KI-Einsatz noch relativ okay. |

Daraus folgt für die KI: Lesbarkeit, Zusammenhalt, Proportionen, persönliche Note und Kanalpassung sind wichtiger als Panelmenge oder möglichst teure Illustrationen. Cute und verspielt darf gut sein. Ein leerer Bereich ist nicht automatisch ein schlechtes minimalistisches Layout. Ein künstlich oder generisch wirkendes Motiv wird nur mit sichtbaren Gründen kritisiert, nicht als sicher KI-generiert bezeichnet.

**Gestaltung und Inhalt werden getrennt betrachtet:** Ein attraktiver Social-Button beweist keinen funktionierenden Link; ein Bildpanel ohne Untertext kann aber selbst verlinkt sein. Sichtbare Platzhalter werden nicht als fertige Inhalte gewertet. Zeitpläne in About-Panels zählen ebenfalls als positive Belege; ein leerer Zeitplan-Tab allein reicht nicht für „kein Zeitplan“.

Die Referenzbilder dienen ausschließlich als Geschmacksanker. Sie erhalten `STYLE_`-IDs und gehören **nicht** zum Belegkatalog des Zielkanals. Der Validator akzeptiert sie nicht als Nachweis für Befunde über den geprüften Streamer. Followerzahlen aus Beispielen geben keine Stilpunkte.

Andere lokale Vorgaben lassen sich mit `--style-profile PFAD_ZUR_JSON` laden. Die verwendete Konfiguration wird als `style_profile_used.json` im Auditordner dokumentiert. Änderungen an einem Referenzbild benötigen einen passenden neuen SHA-256-Wert; ein unerwartet verändertes Bild wird nicht übertragen. Ohne den Bildschalter werden die Referenzdateien nicht für den API-Upload geöffnet.

**Das Paket enthält deine hochgeladenen Beispielausschnitte.** Vor Weitergabe des Programmpakets prüfen, ob diese Beispiele enthalten bleiben sollen. Die eigentlichen Streamer-Reports enthalten die Stilreferenzbilder nicht als eingebettete Grafiken.

## Deine beiden zusätzlichen Prüfpunkte

### 1. Vorhandene VODs, aber nur für Abonnenten

Das ist ein eigener, hoch gewichteter Punkt: **Ohne Abo anschaubar / Besucherhürden**.

Das Programm unterscheidet `subscription_required`, `login_required`, `age_gate`, `unavailable`, `advertisement`, `playback_sample_verified` und `not_verified`. Eine Abo-Schranke wird nur aus einem ausdrücklichen Playerhinweis abgeleitet. Aus dem Helix-Feld `viewable=public` wird **keine** freie Abspielbarkeit abgeleitet.

Bei erkannter Abo-Schranke und ohne bestätigtes frei abspielbares VOD erhält dieses Kriterium im gewählten Entdeckbarkeitsraster 2/10 Punkte; bei einer Mischung aus gesperrten und bestätigt abspielbaren VODs 6/10. Das ist eine konfigurierbare Bewertungsentscheidung für dieses Förderprogramm, keine wissenschaftliche Wachstumskennzahl und keine offizielle Twitch-Wertung. Exklusive Inhalte können bewusst gewünscht sein; der Report beurteilt hier die Einstiegshürde.

Beispiel für die Art des Feedbacks, **kein Befund über earlysalty**:

> Deine Aufzeichnungen sind vorhanden, aber die geprüften Videos verlangen ein Kanalabo. Neue Besucher können sich dadurch nicht ohne Abo einen längeren Eindruck verschaffen. Biete repräsentative Aufzeichnungen oder Highlights frei zugänglich an und zeige gute öffentliche Clips direkt im Profil.

Es werden keine Abos gekauft, keine Zugangssperren umgangen und keine Konten angemeldet.

### 2. Orange markierte Muted-Stellen im VOD

Der Browser zeigt die Playersteuerung, erfasst Screenshots und versucht, beschriftete Muted-Elemente beziehungsweise zugehörige Hinweise sichtbar zu machen. **Die Farbe allein ist kein belastbarer automatischer Nachweis.**

Die zuverlässigere Zeitmarkenquelle ist Twitch Helix `Get Videos`: `muted_segments` enthält laut Twitch Dauer und Startversatz der durch Audio Recognition stummgeschalteten Segmente [1]. Der Bericht erzeugt daraus anklickbare Anfangs- und Endzeitmarken je VOD. `null` wird als „keine Segmente von Twitch gemeldet“ behandelt; ein fehlendes oder unlesbares Feld dagegen als „nicht prüfbar“.

Ohne API-Daten können ausdrückliche Twitch-Player-Beschriftungen einen positiven Hinweis belegen. Exakte Zeiten werden dann nicht erfunden. Widersprechen sich UI und API, wird der Widerspruch zur manuellen Prüfung ausgewiesen. Keine sichtbare Markierung in einem einzelnen Screenshot ist keine Entwarnung für das ganze VOD.

Eine stummgeschaltete Passage beweist weder eine konkrete OBS-Konfiguration noch automatisch einen Rechtsverstoß. Die separate OBS-VOD-Tonspur erlaubt zwar eine andere Audiospur für die Aufzeichnung als für den Livestream [8], liefert aber selbst keine Aussage über vorhandene Musikrechte. Der Report empfiehlt deshalb, Routing und Rechte zu prüfen, statt eine fehlende VOD-Spur zu behaupten.

## Was `--playback` tatsächlich macht

Bei zugänglichen VODs versucht der Browser kurze Stichproben bei ungefähr 10 %, 50 % und 85 % der Laufzeit. Bestätigt wird eine Stichprobe nur bei fortschreitender Wiedergabe und passendem Zeitversatz. Die Medienlänge muss zur von Helix gemeldeten VOD-Länge passen. Ohne diesen Abgleich wird nicht gesprungen und keine freie VOD-Abspielbarkeit bestätigt. Erkannte Werbung oder Zugangsschranken beenden die entsprechende Prüfung.

Der lokale Player wird zur Rücksicht auf deine Umgebung stummgeschaltet. **Das ist nicht die von Twitch vorgenommene VOD-Stummschaltung.** Die KI erhält einzelne Bilder, keine vollständige Aufzeichnung und keine Tonanalyse. Es gibt keinen VOD-Download und keine Analyse der musikalischen oder gesprochenen Inhalte.

## Ergebnisdateien

```text
audits/KANAL_ZEITSTEMPEL/
  evidence.json          Rohdaten, Beleg-IDs, Status und Umfang
  collection.html        Übersicht vor der KI-Übertragung
  screenshots/           Lokale Screenshots mit Prüfsummen
  report.html            Feedback, Prioritäten, Einzelbefunde und Belege
  report.json            Strukturierter Report für eine eigene Anwendung
  report.md              Textfassung
  style_profile_used.json  Verwendete Stilvorgaben mit Referenz-Prüfsummen
```

Die letzten drei Dateien entstehen beim Analyseschritt. Ohne belastbare Daten wird keine KI-Anfrage gesendet und kein schlechter Profilscore erfunden. Bei einem API-Fehler bleiben die schon erfassten Belege erhalten.

`report.html` benötigt die zugehörigen lokalen Screenshot-Dateien. Beim Weitergeben deshalb den ganzen betreffenden Auditordner berücksichtigen und vorher sensible Inhalte sowie die Rohdaten prüfen. Der Report wird nicht automatisch veröffentlicht, verschickt oder als Partnerentscheidung verwendet.

## Gewichtung und Nachvollziehbarkeit

| Kriterium | Gewicht |
| --- | ---: |
| Home / erster Eindruck | 10 % |
| Profilbild | 5 % |
| Banner / Identität | 5 % |
| Bio / About Me | 10 % |
| Social Links | 5 % |
| Panels / Gestaltung | 10 % |
| Clips | 15 % |
| Hervorgehobene Clips | 10 % |
| VOD-Angebot | 5 % |
| Ohne Abo anschaubar | 15 % |
| Gemeldete Muted-Stellen | 5 % |
| Zeitplan | 5 % |

Clips und hervorgehobene Clips wiegen gemeinsam 25 %, der Zeitplan nur 5 %. Das Raster steht unter `CRITERIA` in `twitch_audit.py`; die Gewichte sollten zusammen 100 ergeben. Die festen Zugangs- und Audioregeln stehen in `access_criterion` und `audio_criterion`.

Jedes Kriterium erhält 0–10 Punkte oder `nicht_pruefbar`. Nicht prüfbare Punkte werden aus der Berechnung ausgeschlossen, nicht mit null bestraft. Unter 80 % gewichteter Prüfabdeckung wird kein Gesamtscore veröffentlicht. „Fehlt“ braucht eine passende, hinreichend vollständige Quelle. Ein KI-Befund ohne passenden Beleg wird verworfen; die Zusammenfassung basiert auf den validierten Einzelbefunden.

Die gestalterische Bewertung bleibt subjektiv und wird in 0.3.0 durch deine hinterlegten Vorlieben kalibriert; sie ist nicht empirisch auf Geschmacksübereinstimmung geprüft. Lesbarkeit, Kontrast, visuelle Einheitlichkeit und erkennbare Bildfehler dürfen konkret kritisiert werden. Das System behauptet nicht, die KI-Herkunft eines Panels sicher erkennen zu können.

## Grenzen und sicherer Einsatz

Externe Social-Zielseiten werden nicht besucht. Bewertet werden gefundene Plattformen, Beschriftung, Positionierung und Orientierung im Twitch-Profil – nicht Aktualität, Reichweite oder Qualität der externen Accounts. Es gibt hier keinen bestätigten Link-Funktionstest.

Nur die Desktop-Ansicht wird erfasst. Verdeckte Inhalte, interaktive Erweiterungen, endlos nachladende Seiten, neue Tabs und neue Twitch-Layouts können weitere Anpassungen erfordern. Die zentralen DOM-Selektoren stehen in `browser_dom.js`; Playersteuerung und Datenschutzmasken zusätzlich in `twitch_audit.py`.

Keine privaten GraphQL-Endpunkte, keine Stealth-Patches, keine Cookie-Übernahme, kein CAPTCHA-Lösen, keine simulierten Follows und keine Twitch-Schreibaktionen. Bei einer Umgebungsblockade wird nicht versucht, diese zu umgehen. Vor dem betrieblichen Einsatz die geltenden Plattformbedingungen, Einwilligungen und eigenen Datenverarbeitungsanforderungen prüfen.

`store=false` ist für OpenAI-Anfragen gesetzt. Das ist keine Zusage, dass beim API-Anbieter keinerlei Protokollierung oder Aufbewahrung erfolgt. Für die eigene Nutzung die jeweils geltenden API-Datenregeln prüfen [9]. Kosten hängen vom Modell, den gesendeten Bildern und Texten ab; es wird kein fixer Preis versprochen. `--max-ai-images` begrenzt die Zielkanal-Bildanzahl. Mit `--style-reference-images` kommen bis zu elf zusätzliche Stilreferenzen hinzu und erhöhen den Bildinput. Der Schalter erlaubt ausdrücklich auch die Übermittlung dieser Beispiele. Das Programm sendet keine Twitch-Tokens oder Client-Secrets als Analyseinhalt.

Seiteninhalte können manipulative Anweisungen enthalten. Die KI wird angewiesen, sie ausschließlich als untrusted Daten zu behandeln, erhält keine Werkzeuge und darf keine Aktionen ausführen. Diese Maßnahmen und die Belegprüfung ersetzen keine menschliche Kontrolle des Feedbacks.

## Nützliche Optionen

```bash
python twitch_audit.py collect --help
python twitch_audit.py run --help
python twitch_audit.py analyze --help

# Dialoge selbst prüfen; vor jeder Ansicht im Terminal Enter drücken:
python twitch_audit.py collect earlysalty --consent --interactive

# Nur Browser, keine Helix-Abfragen:
python twitch_audit.py collect earlysalty --consent --no-api

# Umfang anpassen:
python twitch_audit.py run earlysalty --consent --ai-consent --max-vods 8 --max-scrolls 10 --max-ai-images 32 --playback

# Automatisierte Funktionstests, ohne echte Twitch-/OpenAI-Aufrufe:
python -m pytest -q
```

`--interactive` nicht mit `--headless` kombinieren. `--browser-executable` kann auf ein geeignetes bereits installiertes Chromium zeigen. Login-, Alters- und Cookie-Dialoge werden nicht mit erfundenen Antworten bestätigt. Nur klar erkennbare Schaltflächen zum Ablehnen optionaler Cookies können automatisch betätigt werden.

## Technische Quellen

Die folgenden Primärquellen wurden bei der Implementierung am 5. Oktober 2026 herangezogen. Sie beschreiben die API-/Softwarefunktionen; die konkrete Gewichtung dieses Auditors ist ein eigener Entwurf.

1. Twitch Helix – Get Videos (`muted_segments`, `offset`, `duration`): https://dev.twitch.tv/docs/api/reference/#get-videos
2. Twitch Helix – Get Clips (`is_featured`): https://dev.twitch.tv/docs/api/reference/#get-clips
3. Twitch – Get Users und Get Channel Stream Schedule: https://dev.twitch.tv/docs/api/reference/
4. Twitch – Register Your App: https://dev.twitch.tv/docs/authentication/register-app/
5. OpenAI – Images and vision: https://developers.openai.com/api/docs/guides/images-vision
6. OpenAI – Structured outputs: https://developers.openai.com/api/docs/guides/structured-outputs
7. Playwright – Python installation: https://playwright.dev/python/docs/intro
8. OBS – Twitch VOD Track Guide: https://obsproject.com/kb/twitch-vod-track-guide
9. OpenAI – Data controls: https://developers.openai.com/api/docs/guides/your-data


## Änderungsübersicht 0.3.0

Echte Bildreferenzen als explizit aktivierbare Ergänzung, textliche Stilvorgaben standardmäßig, sichere Trennung von Referenzen und Zielbelegen, bevorzugte Auswahl der About-Scrollbilder und Erkennung von Zeitplanbelegen in About. Die bestehende Browser-, VOD-, Clip-, Abo- und Muted-Logik bleibt erhalten.

**84 automatisierte Tests bestanden**, einschließlich echter lokaler Chromium-Screenshots, Aufbau einer Bildanfrage mit Zielbildern plus elf Stilreferenzen und Report-Erzeugung mit einer simulierten Modellantwort. Das ist kein echter OpenAI-Modelllauf. Der erneute Twitch-Browseraufruf für `earlysalty` wurde am 5. Oktober 2026 wieder durch die Ausführungsumgebung mit `ERR_BLOCKED_BY_ADMINISTRATOR` blockiert. Details: `TESTSTATUS.md`.
