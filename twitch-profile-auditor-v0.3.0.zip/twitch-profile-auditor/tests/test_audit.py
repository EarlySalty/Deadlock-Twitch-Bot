from copy import deepcopy
from pathlib import Path
import argparse
import json
import os
import pytest
import twitch_audit as a


def data_template():
    return {'channel':'earlysalty','collected_at':'2026-10-05T00:00:00+00:00',
        'visitor_mode':'fresh_browser_logged_out','consent':{'audit_confirmed':True},'pages':[],
        'api':{k:{'status':'not_configured'} for k in a.API_KEYS},'notes':[]}


def vod(status='subscription_required',player=None):
    p={'id':'p07_vod','kind':'vod','status':'ok','requested_url':'https://www.twitch.tv/videos/123',
       'screenshots':[],'dom_snapshots':[],'player':player or {},'bottom_reached':True}
    if status:p['access']={'status':status,'label':a.ACCESS_DE[status],'gate_text':'Expliziter Testhinweis'}
    return p


@pytest.mark.parametrize('value,expected',[
    ('earlysalty','earlysalty'),(' EarlySalty ','earlysalty'),
    ('https://www.twitch.tv/earlysalty','earlysalty'),('https://twitch.tv/earlysalty/','earlysalty')])
def test_channel_valid(value,expected):assert a.channel_login(value)==expected


@pytest.mark.parametrize('value',['https://evil.example/earlysalty','http://twitch.tv/earlysalty',
    'https://www.twitch.tv/earlysalty/videos','https://user:secret@twitch.tv/earlysalty',
    '../etc/passwd','a'*26,'videos','https://twitch.tv:443/earlysalty'])
def test_channel_invalid(value):
    with pytest.raises(ValueError):a.channel_login(value)


@pytest.mark.parametrize('url',[
    'https://evil.example/earlysalty/about','https://www.twitch.tv/other/about',
    'https://www.twitch.tv/earlysalty/subscribe','https://www.twitch.tv/earlysalty/follow',
    'https://www.twitch.tv/earlysalty/about/deeper','javascript:alert(1)'])
def test_discovery_scope(url):assert a.channel_tab(url,'earlysalty') is None


def test_filter_actions_removed():
    assert a.channel_tab('https://www.twitch.tv/earlysalty/collections?action=delete&sort=time','earlysalty')=='https://www.twitch.tv/earlysalty/collections?sort=time'


def test_weight_total():assert sum(v[1] for v in a.CRITERIA.values())==100


def test_duration():
    assert a.duration_seconds('3h4m5s')==11045
    assert a.duration_seconds('18m')==1080
    assert a.duration_seconds('bad') is None
    assert a.timecode(3723)=='01:02:03'


def test_no_data_is_not_zero_score():
    result=a.score_summary([a.unknown_criterion(k,'Keine Daten') for k in a.CRITERIA])
    assert result['score_on_assessed_criteria'] is None
    assert result['published_score'] is None
    assert result['coverage_percent']==0


@pytest.mark.parametrize('segments,state',[(None,'reported_clear'),([], 'reported_clear'),
    ([{'offset':120,'duration':30}],'reported_muted'),('MISSING','partial'),
    ([{'offset':True,'duration':30}],'partial'),([{'offset':-1,'duration':30}],'partial'),
    ([{'offset':0,'duration':0}],'partial')])
def test_mute_metadata(segments,state):
    video={'id':'123','duration':'1h'}
    if segments!='MISSING':video['muted_segments']=segments
    result=a.muted_audio_summary({'status':'ok','data':[video]})
    assert result['status']==state
    if state=='reported_muted':
        assert result['videos'][0]['segments'][0]['start']=='00:02:00'
        assert result['videos'][0]['segments'][0]['end']=='00:02:30'


@pytest.mark.parametrize('text,expected',[
    ('Abonnieren','not_verified'),('Subscribe','not_verified'),
    ('This video is only available to subscribers','subscription_required'),
    ('Subscriber-only video','subscription_required'),
    ('Dieses Video steht nur Abonnenten zur Verfügung','subscription_required'),
    ('Abonniere, um dieses Video anzusehen','subscription_required'),
    ('Log in to watch this video','login_required'),
    ('Anmelden, um dieses Video zu sehen','login_required'),
    ('Confirm your age to watch','age_gate'),
    ('Content is unavailable','unavailable')])
def test_access_gate_text(text,expected):
    assert a.classify_vod_access({'overlay_texts':[text]}, {})['status']==expected


def test_api_public_not_proof_of_access():
    data=data_template();data['api']['archives']={'status':'ok','data':[{'id':'123','viewable':'public'}]}
    assert a.access_criterion(data).status=='nicht_pruefbar'


def test_sub_gate_penalty_and_clips_separate():
    data=data_template();data['pages']=[vod()]
    c=a.access_criterion(data)
    assert c.status=='verbesserbar' and c.score==2 and c.evidence_ids==['p07_vod_dom']
    assert '1 von 1' in c.observation


def test_failed_page_no_subscriber_claim():
    data=data_template();page=vod();page['status']='blocked';data['pages']=[page]
    assert a.access_criterion(data).status=='nicht_pruefbar'


def test_ui_mute_positive_with_no_api():
    data=data_template();data['pages']=[vod(player={'muted_text_indicators':['Portions of this video have been muted']})]
    c=a.audio_criterion(data)
    assert c.status=='verbesserbar' and c.evidence_ids==['p07_vod_dom']
    assert 'Exakte Zeitbereiche' in c.observation


def test_color_only_never_confirmed_muted():
    data=data_template();data['pages']=[vod(player={'muted_marker_candidates':[{'color':'orange'}]})]
    assert a.audio_criterion(data).status=='nicht_pruefbar'


def test_local_muted_video_setting_not_twitch_mute():
    data=data_template();data['pages']=[vod(player={'muted':True})]
    assert a.audio_criterion(data).status=='nicht_pruefbar'


def test_ui_api_conflict_reported():
    data=data_template();data['pages']=[vod(player={'muted_text_indicators':['Muted audio segment']})]
    data['api']['archives']={'status':'ok','data':[{'id':'123','muted_segments':None}]}
    assert 'Widerspruch' in a.audio_criterion(data).observation


def test_technical_error_not_empty_profile():
    assert a.page_health({},403,'https://www.twitch.tv/a','https://www.twitch.tv/a')[0]=='blocked'
    assert a.page_health({},200,'https://www.twitch.tv/a','https://www.twitch.tv/a')[0]=='unavailable'


def test_skeleton_is_partial():
    dom={'main_found':True,'channel_identity':True,'text':'Ein ausreichend langer Inhalt mit vielen Wörtern.','loading_visible':True}
    assert a.page_health(dom,200,'https://www.twitch.tv/a','https://www.twitch.tv/a')[0]=='partial'


def test_no_missing_featured_claim_from_random_clip_sample():
    data=data_template()
    data['api']['clips']={'status':'ok','data':[{'id':'abc','is_featured':False}],'has_more':True}
    cat=a.evidence_catalog(data,set())
    claim=a.Criterion(id='featured',status='fehlt',score=0,observation='Keine hervorgehobenen Clips.',recommendation='Erstellen.',
        evidence_ids=['api_clips'],confidence='hoch',assessment_type='beobachtung')
    out,notes=a.validate_report(a.AuditOutput(summary='Test',criteria=[claim],other_findings=[]),data,cat)
    assert next(c for c in out.criteria if c.id=='featured').status=='nicht_pruefbar'
    assert notes


def test_missing_claim_cannot_override_api_positive():
    data=data_template();data['api']['clips']={'status':'ok','data':[{'id':'abc'}],'has_more':False}
    claim=a.Criterion(id='clips',status='fehlt',score=0,observation='Keine Clips.',recommendation='Erstellen.',
        evidence_ids=['api_clips'],confidence='hoch',assessment_type='beobachtung')
    out,_=a.validate_report(a.AuditOutput(summary='Test',criteria=[claim],other_findings=[]),data,a.evidence_catalog(data,set()))
    assert next(c for c in out.criteria if c.id=='clips').status=='nicht_pruefbar'


def test_path_traversal_rejected(tmp_path):
    with pytest.raises(ValueError):a.local_file(tmp_path,'../secret')


def test_html_escaping():
    output=a.hyperlink('javascript:alert(1)','<script>bad</script>')
    assert '<script>' not in output and 'href=' not in output


def test_no_evidence_skips_ai_even_without_key(tmp_path,monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY',raising=False)
    a.save_json(tmp_path/'evidence.json',data_template())
    result=a.analyze(tmp_path,argparse.Namespace(ai_consent=True,max_ai_images=5,model='gpt-4.1'))
    assert result['ai']['status']=='not_called_no_evidence'
    assert result['scoring']['published_score'] is None
    for name in ('report.html','report.md','report.json'):assert (tmp_path/name).exists()


def test_browser_collect_requires_consent_before_network():
    with pytest.raises(ValueError,match='consent'):a.collect(argparse.Namespace(consent=False))


def test_analysis_requires_separate_consent(tmp_path):
    with pytest.raises(ValueError,match='ai-consent'):a.analyze(tmp_path,argparse.Namespace(ai_consent=False))


def test_api_requests_and_featured_filter(monkeypatch):
    import httpx
    calls=[]
    def responder(request):
        calls.append(request)
        if request.url.path=='/oauth2/token':return httpx.Response(200,json={'access_token':'fixture-secret-token'})
        if request.url.path=='/helix/users':return httpx.Response(200,json={'data':[{'id':'123','login':'earlysalty','description':'Test bio','email':'not-retained@example.test'}]})
        if request.url.path=='/helix/videos':return httpx.Response(200,json={'data':[{'id':'456','duration':'1h','muted_segments':[{'offset':60,'duration':30}]}]})
        if request.url.path=='/helix/clips':return httpx.Response(200,json={'data':[]})
        if request.url.path=='/helix/schedule':return httpx.Response(404,json={'error':'not found'})
        raise AssertionError(str(request.url))
    original=httpx.Client
    monkeypatch.setattr(a.httpx,'Client',lambda **kwargs:original(transport=httpx.MockTransport(responder),**kwargs))
    monkeypatch.setenv('TWITCH_CLIENT_ID','fixture-client-id');monkeypatch.setenv('TWITCH_CLIENT_SECRET','fixture-client-secret')
    monkeypatch.delenv('TWITCH_ACCESS_TOKEN',raising=False)
    result=a.collect_api('earlysalty',5)
    assert 'email' not in result['profile']['data'][0]
    assert result['schedule']['status']=='unavailable'
    assert any(r.url.params.get('is_featured')=='true' for r in calls)
    assert 'fixture-secret-token' not in json.dumps(result)
    assert a.muted_audio_summary(result['archives'])['reported_segment_count']==1


def test_mocked_ai_pipeline_sends_no_tools_or_keys(tmp_path,monkeypatch):
    import httpx
    data=data_template();data['api']['clips']={'status':'ok','data':[],'has_more':False}
    a.save_json(tmp_path/'evidence.json',data)
    def responder(request):
        payload=json.loads(request.content)
        assert request.url.path=='/v1/responses'
        assert payload['store'] is False and 'tools' not in payload
        assert payload['text']['format']['type']=='json_schema'
        assert payload['text']['format']['strict'] is True
        assert 'do-not-transmit-this-key' not in json.dumps(payload['input'])
        claim=a.Criterion(id='clips',status='fehlt',score=0,observation='Test-API meldet keine Clips.',recommendation='Clips bereitstellen.',evidence_ids=['api_clips'],confidence='hoch',assessment_type='beobachtung')
        output=a.AuditOutput(summary='Synthetische Modellantwort',criteria=[claim],other_findings=[])
        return httpx.Response(200,json={'id':'mock-response','status':'completed',
            'output':[{'type':'message','content':[{'type':'output_text','text':output.model_dump_json()}]}]})
    original=httpx.Client
    monkeypatch.setattr(a.httpx,'Client',lambda **kwargs:original(transport=httpx.MockTransport(responder),**kwargs))
    monkeypatch.setenv('OPENAI_API_KEY','do-not-transmit-this-key')
    result=a.analyze(tmp_path,argparse.Namespace(ai_consent=True,max_ai_images=4,model='gpt-4.1'))
    assert result['ai']['status']=='completed'
    assert next(c for c in result['audit']['criteria'] if c['id']=='clips')['status']=='fehlt'
    assert (tmp_path/'report.html').exists()
