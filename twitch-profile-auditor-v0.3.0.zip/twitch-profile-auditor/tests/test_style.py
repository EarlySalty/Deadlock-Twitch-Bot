"""Style calibration is opt-in for reference pixels and never target evidence."""
import argparse
import base64
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path

from PIL import Image
import pytest
import twitch_audit as a
from style_calibration import load_style_profile, style_prompt


def fixture_data():
    return {'channel':'fixture_streamer','collected_at':a.now(),
            'consent':{'audit_confirmed':True},'pages':[], 'api':{}, 'notes':[]}


def page(kind='about',count=1,complete=True):
    ident='p01_'+kind
    return {'id':ident,'kind':kind,'status':'ok' if complete else 'partial',
            'requested_url':'https://www.twitch.tv/fixture_streamer/'+kind,
            'bottom_reached':complete,'dom_snapshots':[],
            'screenshots':[{'id':f'{ident}_s{i:02d}','file':f'screenshots/{ident}_s{i:02d}.jpg',
                            'label':f'Ansicht {i}'} for i in range(1,count+1)]}


def claim(key,ids,status='gut'):
    return a.Criterion(id=key,status=status,score=8 if status=='gut' else 0,
                       observation='Synthetischer Testbefund',recommendation='Testempfehlung',
                       evidence_ids=ids,confidence='mittel',assessment_type='gestalterische_einschaetzung')


def test_eleven_user_references_with_verified_pixels():
    profile,_=load_style_profile(a.ROOT/'style_profile.json')
    assert len(profile.references)==11
    assert profile.references[2].view=='home'
    for ref in profile.references:
        raw=(a.ROOT/ref.file).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==ref.sha256
        with Image.open(io.BytesIO(raw)) as im:
            assert im.width>=500 and im.height>=200


def test_style_prompt_separates_opinion_provenance_and_target():
    profile,_=load_style_profile(a.ROOT/'style_profile.json')
    text=style_prompt(profile)
    assert 'STYLE_' in text and 'evidence_ids' in text and 'Follower' in text
    assert 'file' not in json.loads(text.split('\n')[-1])
    assert 'sha256' not in text
    assert 'keine Belege' not in profile.title  # Title remains a human-readable preference label.


@pytest.mark.parametrize('relative',['../outside.jpg','/etc/private.jpg','style_references/../../secret.jpg','style_references/x.txt'])
def test_profile_rejects_unsafe_reference_paths(tmp_path,relative):
    data=json.loads((a.ROOT/'style_profile.json').read_text())
    data['references'][0]['file']=relative
    p=tmp_path/'style.json';a.save_json(p,data)
    with pytest.raises(ValueError):load_style_profile(p)


def test_duplicate_reference_ids_rejected(tmp_path):
    data=json.loads((a.ROOT/'style_profile.json').read_text())
    data['references'][1]['id']=data['references'][0]['id']
    p=tmp_path/'style.json';a.save_json(p,data)
    with pytest.raises(ValueError,match='Doppelte'):load_style_profile(p)


def test_default_never_opens_reference_images(monkeypatch):
    def forbidden(*_args,**_kwargs):raise AssertionError('Reference images must remain local by default')
    monkeypatch.setattr(a,'image_content',forbidden)
    _prompt,images,info,_=a.prepare_style(a.ROOT/'style_profile.json',False,True,1_000_000)
    assert not images and info['reference_image_count']==0


def test_reference_images_require_target_screenshots():
    _prompt,images,info,_=a.prepare_style(a.ROOT/'style_profile.json',True,False,10_000_000)
    assert images==[] and info['reference_image_count']==0
    assert info['skipped_reference_images']


def test_explicit_opt_in_sends_eleven_real_image_payloads():
    _prompt,images,info,_=a.prepare_style(a.ROOT/'style_profile.json',True,True,35_000_000)
    pixels=[i for i in images if i['type']=='input_image']
    assert len(pixels)==11 and info['reference_image_count']==11
    for item in pixels:
        raw=base64.b64decode(item['image_url'].split(',',1)[1])
        with Image.open(io.BytesIO(raw)) as im:
            assert im.format=='JPEG'


def test_reference_images_respect_request_budget():
    _prompt,images,info,_=a.prepare_style(a.ROOT/'style_profile.json',True,True,1)
    assert images==[] and len(info['skipped_reference_images'])==11


def test_tampered_reference_not_transmitted(tmp_path):
    image=tmp_path/'fake.jpg';Image.new('RGB',(20,20)).save(image)
    data=json.loads((a.ROOT/'style_profile.json').read_text())
    data['references']=data['references'][:1]
    data['references'][0]['file']='fake.jpg'
    path=tmp_path/'style.json';a.save_json(path,data)
    _prompt,images,info,_=a.prepare_style(path,True,True,100000)
    assert images==[] and 'verändert' in info['skipped_reference_images'][0]


def test_cli_opt_in_is_explicit():
    args=a.parser().parse_args(['run','earlysalty','--consent','--ai-consent'])
    assert args.style_reference_images is False
    args=a.parser().parse_args(['run','earlysalty','--consent','--ai-consent','--style-reference-images'])
    assert args.style_reference_images is True


def test_visual_selection_covers_views_and_about_panels():
    pages=[page('home',7),page('about',7)]+[page(k,3) for k in ('videos','clips','schedule','archives','highlights')]
    data={'pages':pages};shots=a.select_shots(data,18)
    assert len(shots)==18
    assert len({s['id'] for s in shots})==18
    assert {p['screenshots'][0]['id'] for p in pages} <= {s['id'] for s in shots}
    assert {s['id'] for s in pages[1]['screenshots']} <= {s['id'] for s in shots}


def test_zero_image_budget_returns_none():
    assert a.select_shots({'pages':[page()]},0)==[]


def test_reference_is_not_valid_evidence_for_target():
    data=fixture_data();p=page();data['pages']=[p]
    ids={s['id'] for s in p['screenshots']};catalog=a.evidence_catalog(data,ids)
    out,notes=a.validate_report(a.AuditOutput(summary='Test',criteria=[claim('panels',['STYLE_02'])],other_findings=[]),data,catalog)
    c=next(c for c in out.criteria if c.id=='panels')
    assert c.status=='nicht_pruefbar' and notes
    assert all(not k.startswith('STYLE_') for k in catalog)


def test_schedule_image_in_about_is_valid_positive_evidence():
    data=fixture_data();p=page();data['pages']=[p]
    ids={s['id'] for s in p['screenshots']};catalog=a.evidence_catalog(data,ids)
    out,_=a.validate_report(a.AuditOutput(summary='Test',criteria=[claim('schedule',list(ids))],other_findings=[]),data,catalog)
    assert next(c for c in out.criteria if c.id=='schedule').status=='gut'


def test_empty_schedule_tab_without_about_cannot_prove_no_schedule():
    data=fixture_data();p=page('schedule');data['pages']=[p]
    ids={s['id'] for s in p['screenshots']};catalog=a.evidence_catalog(data,ids)
    out,notes=a.validate_report(a.AuditOutput(summary='Test',criteria=[claim('schedule',list(ids),'fehlt')],other_findings=[]),data,catalog)
    assert next(c for c in out.criteria if c.id=='schedule').status=='nicht_pruefbar'
    assert notes


def test_schedule_api_positive_overrules_missing_claim():
    data=fixture_data();data['pages']=[page('schedule'),page('about')]
    data['api']['schedule']={'status':'ok','data':{'segments':[{'id':'example'}]}}
    ids={s['id'] for p in data['pages'] for s in p['screenshots']};catalog=a.evidence_catalog(data,ids)
    out,notes=a.validate_report(a.AuditOutput(summary='Test',criteria=[claim('schedule',['p01_schedule_s01'],'fehlt')],other_findings=[]),data,catalog)
    assert next(c for c in out.criteria if c.id=='schedule').status=='nicht_pruefbar'
    assert notes
