"""Rendered-browser regression tests with rendered local HTML; navigation is mocked, never live Twitch calls."""
import argparse
import os
from pathlib import Path
import pytest
from playwright.sync_api import sync_playwright
import twitch_audit as a


@pytest.fixture(scope='module')
def browser():
    with sync_playwright() as pw:
        options={'headless':True}
        if os.environ.get('AUDIT_TEST_BROWSER'):options['executable_path']=os.environ['AUDIT_TEST_BROWSER']
        b=pw.chromium.launch(**options)
        yield b
        b.close()


@pytest.fixture
def page(browser):
    context=browser.new_context(viewport={'width':1440,'height':1000})
    page=context.new_page()
    page.route('**/*',lambda r:r.abort())
    yield page
    context.close()


def fixture_html(player='',extra=''):
    return f'''<!doctype html><html><head><title>fixture_streamer · SYNTHETISCHER TEST</title>
    <style>body{{margin:0;background:#f5f5fa;font:18px Arial}}main{{margin:30px 80px}}.video-player{{height:300px;width:900px;background:#222;color:white;padding:20px}}
    .side-nav{{width:150px;height:200px}}.panel{{border:1px solid gray;padding:24px;margin:15px 0}}</style></head><body>
    <aside class="side-nav">PRIVATE SIDEBAR USERNAME</aside><main><h1>fixture_streamer</h1><nav><a href="https://www.twitch.tv/fixture_streamer/about">About</a>
    <a href="https://www.twitch.tv/fixture_streamer/collections">Collections</a><a href="https://www.twitch.tv/fixture_streamer/subscribe">Abonnieren</a></nav>
    <div class="video-player" data-a-target="video-player">{player}</div>
    <section class="panel">About me · Dies ist ein synthetischer Funktionstest, kein echtes Twitch-Profil.</section>{extra}</main></body></html>'''


def test_player_gate_scoping(page):
    page.set_content(fixture_html('Öffentliches Beispielvideo. <button>Abonnieren</button>',
        '<section class="panel">Mein Discord ist nur für Abonnenten.</section>'))
    media=page.evaluate(a.DOM_JS,{'action':'media','channel':'fixture_streamer'})
    assert a.classify_vod_access(media,{})['status']=='not_verified'


def test_explicit_sub_gate_detected(page):
    page.set_content(fixture_html('<h2>Dieses Video steht nur Abonnenten zur Verfügung</h2>'))
    media=page.evaluate(a.DOM_JS,{'action':'media','channel':'fixture_streamer'})
    assert a.classify_vod_access(media,{})['status']=='subscription_required'


def test_mute_semantics_not_volume_button(page):
    page.set_content(fixture_html('<button aria-label="Unmute">Ton an</button><span title="Muted audio segment">orange segment</span>'))
    media=page.evaluate(a.DOM_JS,{'action':'media','channel':'fixture_streamer'})
    assert media['muted_text_indicators']==['Muted audio segment']


def test_color_only_not_confirmed(page):
    page.set_content(fixture_html('<div style="width:120px;height:10px;background:orange"></div>'))
    media=page.evaluate(a.DOM_JS,{'action':'media','channel':'fixture_streamer'})
    assert not media['muted_text_indicators']


def test_dom_identity_and_panels(page):
    page.set_content(fixture_html())
    dom=page.evaluate(a.DOM_JS,{'action':'extract','channel':'fixture_streamer'})
    assert dom['channel_identity'] and len(dom['panels'])==1
    assert 'PRIVATE SIDEBAR' not in dom['text']
    assert any('collections' in link['href'] for link in dom['nav_links'])


def test_visit_pipeline_and_report_on_rendered_fixture(page,tmp_path):
    html=fixture_html('<h2>Subscriber-only video</h2><span title="Muted audio segment">Markierung</span>')
    args=argparse.Namespace(page_delay=0,timeout=10,settle_ms=100,interactive=False,max_scrolls=2,playback=True)
    collector=a.BrowserCollector(page,tmp_path,'fixture_streamer',args)
    def synthetic_navigation(url):
        page.set_content(html)
        return 200,'synthetic_set_content'
    collector.navigate=synthetic_navigation
    result=collector.visit('vod','about:blank',1,3600)
    assert result['status']=='ok',result
    assert result['access']['status']=='subscription_required'
    assert result['playback']['status']=='access_gate'
    assert len(result['screenshots'])>=2
    assert result['player']['muted_text_indicators']
    data={'channel':'fixture_streamer','collected_at':a.now(),'visitor_mode':'fresh_browser_logged_out',
          'pages':[result],'api':{},'notes':['SYNTHETISCHER TEST']}
    a.write_collection_report(tmp_path,data)
    assert (tmp_path/'collection.html').exists()
    assert 'Subscriber-only video' in (tmp_path/'collection.html').read_text()


def test_full_twitch_muting_sentence(page):
    page.set_content(fixture_html('<p>Portions of this video have been muted as it appears to contain copyrighted content.</p>'))
    media=page.evaluate(a.DOM_JS,{'action':'media','channel':'fixture_streamer'})
    assert len(media['muted_text_indicators'])==1


def test_real_browser_pixels_to_mock_ai_report(page,tmp_path,monkeypatch):
    """Actual rendered screenshot -> real request payload -> simulated model -> report."""
    import base64
    import io
    import json
    import httpx
    from PIL import Image
    args=argparse.Namespace(page_delay=0,timeout=10,settle_ms=100,interactive=False,max_scrolls=2,playback=False)
    collector=a.BrowserCollector(page,tmp_path,'fixture_streamer',args)
    def navigation(_url):
        page.set_content(fixture_html('', '<section class="panel">Über mich, Regeln und öffentliche Social-Verweise.</section>'))
        return 200,'synthetic_set_content'
    collector.navigate=navigation
    captured=collector.visit('about','about:blank',1)
    assert captured['screenshots'] and captured['status']=='ok'
    data={'channel':'fixture_streamer','collected_at':a.now(),'visitor_mode':'fresh_browser_logged_out',
          'consent':{'audit_confirmed':True},'pages':[captured],'api':{},'notes':['SYNTHETISCHER TEST']}
    a.save_json(tmp_path/'evidence.json',data)
    def responder(request):
        body=json.loads(request.content)
        assert body['store'] is False and 'tools' not in body
        assert 'GESTALTUNGSMASSSTAB' in body['input'][0]['content']
        content=body['input'][1]['content']
        inputs=[part for part in content if part['type']=='input_image']
        # The eleven reference crops are additional, not mistaken for target screenshots.
        assert len(inputs)==len(captured['screenshots'])+11
        with Image.open(io.BytesIO(base64.b64decode(inputs[-1]['image_url'].split(',',1)[1]))) as im:
            assert im.width==1440 and im.height==1000
        report=a.AuditOutput(summary='Synthetische KI-Antwort – kein echter Modelllauf',
            criteria=[a.Criterion(id='panels',status='gut',score=8,
                observation='Synthetischer Befund: gerenderte Testpanels.',
                recommendation='Nur Testausgabe, kein Feedback zu einem echten Kanal.',
                evidence_ids=[captured['screenshots'][0]['id']],confidence='mittel',
                assessment_type='gestalterische_einschaetzung')],other_findings=[])
        return httpx.Response(200,json={'id':'synthetic-vision-pipeline','status':'completed',
             'output':[{'type':'message','content':[{'type':'output_text','text':report.model_dump_json()}]}]})
    original=httpx.Client
    monkeypatch.setattr(a.httpx,'Client',lambda **kwargs:original(transport=httpx.MockTransport(responder),**kwargs))
    monkeypatch.setenv('OPENAI_API_KEY','synthetic-no-real-api-key')
    output=a.analyze(tmp_path,argparse.Namespace(ai_consent=True,max_ai_images=24,model='gpt-4.1',style_reference_images=True))
    assert output['ai']['style_calibration']['reference_image_count']==11
    assert output['scoring']['published_score'] is None  # Only panel criterion is supported.
    assert (tmp_path/'report.html').exists() and (tmp_path/'style_profile_used.json').exists()
    assert 'Gestaltungsmaßstab' in (tmp_path/'report.html').read_text()
