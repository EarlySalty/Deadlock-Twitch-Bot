/* Public, rendered channel content only. Selectors are intentionally centralized.
   No private GraphQL, no cookies/tokens, no action buttons, no external crawling. */
({action = 'extract', channel = ''} = {}) => {
  const privacy = '[data-a-target="side-nav-bar"],.side-nav,.right-column,.chat-room,.top-nav,[data-a-target="user-menu-toggle"]';
  const root = document.querySelector('main') || document.querySelector('[role="main"]');
  const shown = e => {
    if (!e || e.closest(privacy)) return false;
    const r = e.getBoundingClientRect(), s = getComputedStyle(e);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const inView = e => {
    if (!shown(e)) return false;
    const r = e.getBoundingClientRect();
    return r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  };
  const trim = (s, n = 1600) => (s || '').trim().slice(0, n);
  const scroller = () => {
    const marked = document.querySelector('[data-profile-audit-scroll="yes"]');
    if (marked && shown(marked)) return marked;
    const all = [document.scrollingElement];
    if (root) {
      all.push(root, ...root.querySelectorAll('*'));
      let p = root.parentElement;
      while (p) { all.push(p); p = p.parentElement; }
    }
    const candidates = [...new Set(all)].filter(e => {
      if (!e || e.closest(privacy)) return false;
      const r = e.getBoundingClientRect();
      return r.width > innerWidth * .45 && e.clientHeight > 150 &&
        e.scrollHeight > e.clientHeight + 8 &&
        (e === document.scrollingElement || /(auto|scroll)/.test(getComputedStyle(e).overflowY));
    });
    candidates.sort((a,b) => (b.scrollHeight-b.clientHeight) - (a.scrollHeight-a.clientHeight));
    const e = candidates[0] || document.scrollingElement;
    if (e) e.setAttribute('data-profile-audit-scroll', 'yes');
    return e;
  };
  const scrollInfo = () => {
    const e = scroller();
    if (!e) return {y:0, height:0, viewport:innerHeight, bottom:true};
    return {y: Math.round(e.scrollTop), height:e.scrollHeight, viewport:e.clientHeight,
      bottom:e.scrollHeight - e.clientHeight - e.scrollTop < 8};
  };
  if (action === 'scroll_top' || action === 'scroll_next') {
    const e = scroller();
    if (e) e.scrollTop = action === 'scroll_top' ? 0 : e.scrollTop + Math.max(150, e.clientHeight*.8);
    return scrollInfo();
  }
  if (action === 'pause') {
    document.querySelectorAll('video').forEach(v => v.pause());
    return true;
  }
  const player = document.querySelector('[data-a-target="video-player"]') || document.querySelector('.video-player');
  if (action === 'media') {
    const v = player?.querySelector('video') || document.querySelector('video');
    const ads = [...document.querySelectorAll('[data-a-target="video-ad-label"],[data-test-selector="ad-banner-default-text"],[data-a-target="ad-banner-default-text"]')].some(inView);
    const markers = player ? [...player.querySelectorAll('[aria-label],[title],[data-a-target],[data-test-selector]')].filter(e => {
      const semantic = [e.getAttribute('aria-label'),e.getAttribute('title'),e.getAttribute('data-a-target'),e.getAttribute('data-test-selector')].join(' ');
      return shown(e) && /muted[ _-](?:segment|audio)|audio.*(?:muted|copyright|stummgeschaltet)|(?:portion|part|section|segment|abschnitt|teil).*(?:muted|stummgeschaltet)|stummgeschaltet.*audio/i.test(semantic);
    }).slice(0,40).map(e => ({label:trim(e.getAttribute('aria-label') || e.getAttribute('title') || e.innerText,300),
      selector_hint:e.getAttribute('data-a-target') || e.getAttribute('data-test-selector')})) : [];
    // Restrict gate detection to rendered player overlays, not About panels or Subscribe buttons.
    const gates = [...document.querySelectorAll('[data-a-target="content-overlay-gate"],[data-a-target*="player-overlay"],[data-test-selector*="content-overlay"],[data-test-selector*="subscribe-overlay"]')].filter(inView);
    const overlayTexts = [...new Set([...(player && inView(player) ? [trim(player.innerText,6000)] : []), ...gates.map(e=>trim(e.innerText,2000))])].filter(Boolean);
    const mutedPattern = /(?:audio|portion|segment|section|abschnitt|ton|teile).{0,120}(?:has been muted|have been muted|was muted|were muted|is muted|are muted|stummgeschaltet)|muted.{0,35}(?:audio|segment|portion)|stummgeschaltete.{0,35}(?:abschnitt|bereich)|audio.{0,80}copyright/i;
    const labels = markers.map(m=>m.label);
    const tooltipTexts = [...document.querySelectorAll('[role="tooltip"],.tw-tooltip,[data-a-target*="tooltip"]')].filter(inView).map(e=>trim(e.innerText,1500));
    const mutedTexts = [...new Set([...labels,...overlayTexts,...tooltipTexts])].filter(t=>mutedPattern.test(t) && !/no muted|not muted|nicht stummgeschaltet|keine stummgeschalteten/i.test(t));
    return {overlay_texts:overlayTexts,muted_text_indicators:mutedTexts,found:!!v, duration:v && Number.isFinite(v.duration) ? v.duration : null,
      current_time:v && Number.isFinite(v.currentTime) ? v.currentTime : null,
      paused:v ? v.paused : null, ready_state:v ? v.readyState : null,
      error_code:v?.error?.code || null, advertisement_visible:ads, muted_marker_candidates:markers};
  }
  const bodyText = document.body?.innerText || '';
  const dialogs = [...document.querySelectorAll('[role="dialog"],[aria-modal="true"]')].filter(inView).map(e => trim(e.innerText,700));
  const systemTexts = [...document.querySelectorAll('[role="alert"],h1,h2,[data-a-target="content-overlay-gate"]')].filter(inView).map(e => trim(e.innerText,500));
  if (!root) return {main_found:false, title:document.title, text:'', links:[], images:[], backgrounds:[], panels:[], nav_links:[],
    dialogs, system_text:systemTexts.join('\n').slice(0,2000), scroll:scrollInfo(), channel_identity:false};
  // innerText must be read on the live DOM for rendered text; exclude private regions line-by-line.
  let text = root.innerText || '';
  root.querySelectorAll(privacy).forEach(e => { if(e.innerText) text=text.replace(e.innerText,''); });
  const links = [...root.querySelectorAll('a[href]')].filter(shown).slice(0,350).map(a => ({
    href:a.href, text:trim(a.innerText || a.getAttribute('aria-label') || a.querySelector('img')?.alt,350),
    in_view:inView(a), navigation:!!a.closest('nav,[role="tablist"],[data-a-target*="channel-nav"],[data-test-selector*="channel-nav"]') || a.getAttribute('role')==='tab'
  }));
  const images = [...root.querySelectorAll('img')].filter(shown).slice(0,180).map(i => ({
    src:i.currentSrc || i.src, alt:trim(i.alt,350), loaded:i.complete && i.naturalWidth>0,
    natural_width:i.naturalWidth,natural_height:i.naturalHeight,
    rendered_width:Math.round(i.getBoundingClientRect().width),rendered_height:Math.round(i.getBoundingClientRect().height),
    in_view:inView(i), target:i.getAttribute('data-a-target') || i.parentElement?.getAttribute('data-a-target') || ''
  }));
  // CSS banners are not necessarily <img> elements.
  const backgrounds = [...root.querySelectorAll('*')].filter(e => shown(e) && e.getBoundingClientRect().width>180).slice(0,3000)
    .map(e => ({url:getComputedStyle(e).backgroundImage,width:Math.round(e.getBoundingClientRect().width),
      height:Math.round(e.getBoundingClientRect().height),in_view:inView(e),target:e.getAttribute('data-a-target')||''}))
    .filter(x=>x.url && x.url!=='none').slice(0,80);
  const panelSelector = '[data-a-target="channel-panel"],[data-test-selector="channel-panel"],.channel-panel,.panel';
  let panelEls = [...root.querySelectorAll(panelSelector)].filter(shown);
  if (!panelEls.length) panelEls = [...root.querySelectorAll('img[src*="panel-"]')].filter(shown).map(i=>i.closest('section,article')||i.parentElement);
  panelEls = [...new Set(panelEls)].filter(e=>!panelEls.some(o=>o!==e && o.contains(e)));
  const panels = panelEls.slice(0,40).map(e=>({text:trim(e.innerText,2000),in_view:inView(e),
    images:[...e.querySelectorAll('img')].map(i=>({src:i.currentSrc||i.src,alt:i.alt})),
    links:[...e.querySelectorAll('a[href]')].map(a=>({href:a.href,text:trim(a.innerText,200)}))}));
  const empties = text.split('\n').map(x=>x.trim()).filter(x=>x.length<220 &&
    /no (videos|clips|scheduled streams)|has(n.t| not) (streamed|scheduled)|keine (videos|clips|geplanten streams)|noch keine/i.test(x));
  return {main_found:true,title:document.title,text:text.slice(0,22000),text_truncated:text.length>22000,
    links,images,backgrounds,panels,nav_links:links.filter(x=>x.navigation),dialogs,
    system_text:systemTexts.join('\n').slice(0,3000),empty_messages:empties,
    loading_visible:[...root.querySelectorAll('[aria-busy="true"],[data-a-target*="skeleton"],[data-test-selector*="skeleton"],[role="progressbar"]')].some(inView),
    channel_identity:!!channel && (text.toLowerCase().includes(channel.toLowerCase()) ||
      [...root.querySelectorAll('a[href]')].some(a=>{try{return new URL(a.href).pathname.toLowerCase()===`/${channel.toLowerCase()}`;}catch{return false;}})),
    scroll:scrollInfo(), visible_body_characters:bodyText.length};
}
